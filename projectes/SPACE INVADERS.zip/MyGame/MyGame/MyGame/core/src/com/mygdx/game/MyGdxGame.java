package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.utils.ScreenUtils;

import java.awt.Shape;
import java.util.ArrayList;

public class MyGdxGame extends ApplicationAdapter implements Runnable, InputProcessor {
	private int PANT_AMPL;
	private int PANT_LLAR;

	SpriteBatch batch;
	Texture imgnau1;
	Texture imgnau2;
	Texture imgnau2e;
	Texture imgnauvida;
	Texture imgnauvida2;
	Texture imgnauvida3;
	Texture dispar;
	Texture disparEnemic;
	private int puntuacion = -1;
	private String puntosPantalla;
	private String puntosPantalla2;
	private int cordenadasTxtX;
	private int cordenadasTxtY;
	private boolean control;
	private boolean controldis1;
	private boolean controldis2;

	private float vidasJugador;

	private Sprite sprite1;
	private Sprite sprite2;

	private ShapeRenderer sr;
	private BitmapFont font;
	private BitmapFont font2;

	long tInicio = 0;
	long tFinal = 0;

	long disparInicio = 0;
	long disparFinal = 0;
	long disparEnemicInici = 0;
	long disparEnemicFinal = 0;

	private int tmpAparecer = 5000;
	private int disparAparecer = 1500;
	private int disparAparecerEnemic = 3000;
	private int contadorNaves;
	private int naveActual;
	private int cuenta;
	private int puntuacionComparada;

	ArrayList<Sprite> sprites;
	ArrayList<Sprite> spritestrets;
	ArrayList<Sprite> spritestretsPantalla;
	ArrayList<Sprite> spritestretsEnemicsPantalla;
	ArrayList<Sprite> aRemover;
	ArrayList<Thread> hilos;
	Thread thread;

	private int points = 0;
	@Override
	public void create () {
		Gdx.input.setInputProcessor(this);

		control = false;
		controldis1 = false;
		controldis2 = false;

		vidasJugador = 4;
		contadorNaves = 0;
		naveActual = 0;
		cuenta = 1;

		sprites = new ArrayList<>();
		spritestrets = new ArrayList<>();
		spritestretsPantalla = new ArrayList<>();
		spritestretsEnemicsPantalla = new ArrayList<>();
		aRemover = new ArrayList<>();
		puntuacionComparada = 500;

		tInicio = System.currentTimeMillis();
		disparInicio = System.currentTimeMillis();
		disparEnemicInici = System.currentTimeMillis();

		puntuacion=0;
		puntosPantalla = "Puntos totales: "+puntuacion;
		puntosPantalla2 = "Daño recivido: " + /*(int)vidasJugador*/0;

		font = new BitmapFont();
		font2 = new BitmapFont();
		cordenadasTxtX = 0;
		cordenadasTxtY = 0;

		PANT_AMPL = Gdx.graphics.getWidth();
		PANT_LLAR = Gdx.graphics.getHeight();

		batch = new SpriteBatch();

		sr = new ShapeRenderer();

		imgnau1 = new Texture("naugran.png");
		imgnauvida = new Texture("vida.png");
		imgnauvida2 = new Texture("vida.png");
		imgnauvida3 = new Texture("vida.png");
		imgnau2 = new Texture("naugranmala.png");
		dispar = new Texture("jefe.jpg");
		disparEnemic = new Texture("jefeEne.jpg");

		sprite1 = new Sprite(imgnau1, 0, 0, imgnau1.getWidth(), imgnau1.getHeight());
		sprite1.setX((PANT_AMPL - imgnau1.getWidth())/2F);
		sprite1.setY(150 + (imgnau1.getHeight()/2F));



		sprite2 = new Sprite(imgnau2, 0, 0, imgnau2.getWidth(), imgnau2.getHeight());

		sprites.add(sprite2);



		thread = new Thread(this);
		thread.start();



	}


	@Override
	public void render () {
		synchronized (this) {
			Gdx.gl.glClearColor(0, 0, 0, 1);

			for (Sprite remueve : aRemover ) {
				spritestretsPantalla.remove(remueve);
			}

			if ( puntuacion >= puntuacionComparada){
				if (vidasJugador<3){
					vidasJugador++;
				}

				puntuacionComparada += puntuacionComparada;
			}

			tFinal = System.currentTimeMillis() - tInicio;
			disparFinal = System.currentTimeMillis() - disparInicio;
			disparEnemicFinal = System.currentTimeMillis() - disparEnemicInici;

			Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
			ScreenUtils.clear(0, 0, 0, 1);

			sr.begin(ShapeType.Filled);
			sr.setColor(Color.WHITE);
			sr.rect(0, 180, PANT_AMPL, 10);

			sr.end();

			batch.begin();
			sprite1.draw(batch);
			//dibuixarObjectes
			//sprite2.draw(batch);
			for (Sprite item : sprites) {

				/*if(item.getX() >= sprite1.getX() && item.getX()
						<= sprite1.getX() + sprite1.getWidth() && item.getY()<=sprite1.getY()+sprite1.getHeight()){

					vidasJugador--;
					//points += 100;
					puntosPantalla2 = "Daño recivido: " + (*//*int) (3 - *//*points);
				}*/
				/*if (item.getX() <= sprite1.getX() + sprite1.getWidth() && item.getY() <= sprite1.getY() + sprite1.getHeight()){
					vidasJugador--;
					item.setX(0);
					item.setY(0 - item.getHeight());
				}else if (item.getX() + item.getWidth() >= sprite1.getX() && item.getY() <= sprite1.getY() + sprite1.getHeight()){
					vidasJugador--;
					item.setX(0);
					item.setY(0 - item.getHeight());
				}*/

				item.draw(batch);
			}
			if (tFinal >= tmpAparecer) {
				if (sprites.size() < 7) {
					sprites.add(new Sprite(imgnau2, 0, 0, imgnau2.getWidth(), imgnau2.getHeight()));
					//control = true;
					sprites.get(sprites.size() - 1).draw(batch);
					sprites.get(sprites.size() - 1).setX(PANT_AMPL / 2 - (imgnau2.getWidth() / 2));
					sprites.get(sprites.size() - 1).setY(PANT_LLAR - imgnau2.getHeight());

					thread = new Thread(this);
					thread.start();
					naveActual++;
				}
				tFinal = 0;
				tmpAparecer += 5000;
			}

			if (disparFinal >= disparAparecer) {
				if (spritestrets.size() < 2) {
					spritestrets.add(new Sprite(dispar, 0, 0, dispar.getWidth(), dispar.getHeight()));
				}
				disparFinal = 0;
				disparAparecer += 1500;
			}





			if (vidasJugador >= 3) {
				batch.draw(imgnauvida, PANT_AMPL - (imgnau1.getWidth() / 2F) + 50, 150 - imgnau1.getHeight() / 2F);
				batch.draw(imgnauvida2, PANT_AMPL - ((imgnau1.getWidth() * 2) / 2F) + 100, 150 - imgnau1.getHeight() / 2F);
				batch.draw(imgnauvida2, PANT_AMPL - ((imgnau1.getWidth() * 3) / 2F) + 150, 150 - imgnau1.getHeight() / 2F);
			}
			if (vidasJugador < 3 && vidasJugador >= 2) {
				batch.draw(imgnauvida, PANT_AMPL - (imgnau1.getWidth() / 2F) + 50, 150 - imgnau1.getHeight() / 2F);
				batch.draw(imgnauvida2, PANT_AMPL - ((imgnau1.getWidth() * 2) / 2F) + 100, 150 - imgnau1.getHeight() / 2F);
			}
			if (vidasJugador < 2 && vidasJugador >= 1) {
				batch.draw(imgnauvida, PANT_AMPL - (imgnau1.getWidth() / 2F) + 50, 150 - imgnau1.getHeight() / 2F);
			}
			if (vidasJugador < 1 && vidasJugador >= 0) {
				batch.draw(imgnauvida, PANT_AMPL - (imgnau1.getWidth() / 2F) + 50, 150 - imgnau1.getHeight() / 2F);
			}
			if (vidasJugador == 0) {

			}


			font.getData().setScale(4F);
			font.setColor(Color.YELLOW);
			font.draw(batch, puntosPantalla, cordenadasTxtX, cordenadasTxtY + 150);
			font2.getData().setScale(4F);
			font2.setColor(Color.RED);
			font2.draw(batch, puntosPantalla2 , cordenadasTxtX, cordenadasTxtY + 80);

			for (Sprite tret : spritestretsPantalla) {
				tret.setY(tret.getY() + 10);
				tret.draw(batch);
			}
			//synchronized (this) {
				for (Sprite tret : spritestretsEnemicsPantalla) {
					if (tret.getY() >= sprite1.getY() + sprite1.getHeight()) {
						tret.setY(tret.getY() - 7);
						tret.draw(batch);
						if (tret.getX() >= sprite1.getX() && tret.getX() <= sprite1.getX() + sprite1.getWidth() && tret.getY() <= sprite1.getY() + sprite1.getHeight()) {
							if (vidasJugador>=0) {
								vidasJugador = (float) (vidasJugador - 0.10);
								tret.setX(-1000);
								tret.setY(0 - tret.getHeight());

								points += 10;
								puntosPantalla2 = "Daño recivido: " + (/*int) (3 - */points);
							}
						}


					}  else if (tret.getX() < sprite1.getX() && sprite1.getY() <= tret.getY() || tret.getX() > sprite1.getX() + sprite1.getWidth() && sprite1.getY() <= tret.getY()){
						/*tret.setX(0);
						tret.setY(0);*/
						tret.setY(tret.getY() - 7);
						tret.draw(batch);
					}else{
						tret.setX(-50);
						tret.setY(-50);
						tret.draw(batch);
					}

				}
			//}
			batch.end();
			puntosPantalla2 = "Daño recivido: " + (/*int) (3 - */points);
			if (vidasJugador <= 0){
				Gdx.app.exit();
			}
		}
		/*if (disparEnemicFinal >= disparAparecerEnemic) {
		disparEnemicFinal = 0;
			disparAparecerEnemic += 3000;
		}*/
	}

	private void movilizar(Sprite y) {
		//Sprite y = sprites.get(sprites.size()-1);

			/*int movimentHoritzontalNaus2 = PANT_AMPL / 2 - (imgnau2.getWidth() / 2);
			int movimentVerticalNaus2 = PANT_LLAR - imgnau2.getHeight();
			int movimentVerticalFinal = *//*(PANT_LLAR + 300) - (PANT_LLAR)*//*(int) (sprite1.getY()*//*+sprite1.getHeight()*//*);

			int direccio = (int) (1 + (Math.random() * 2));
			int velocitat = (int) (1 + (Math.random() * 4));

		*//*movimentHoritzontalNaus2 = PANT_AMPL / 2 - (imgnau2.getWidth() / 2);
		movimentVerticalNaus2 = PANT_LLAR - imgnau2.getHeight();*//*
			//for (Sprite y : prueba) {
		synchronized (y) {
			y.setX(PANT_AMPL / 2 - (imgnau2.getWidth() / 2));
			y.setY(PANT_LLAR - imgnau2.getHeight());
		}

		while(movimentVerticalFinal < movimentVerticalNaus2*//* && vidasJugador > 0*//*){




			if (direccio == 1) {

				for (int posi = movimentHoritzontalNaus2; movimentHoritzontalNaus2 < PANT_AMPL - imgnau2.getWidth(); movimentHoritzontalNaus2 += velocitat) {
					if (disparEnemicFinal >= disparAparecerEnemic) {
						synchronized (this) {
							spritestretsEnemicsPantalla.add(new Sprite(disparEnemic, 0, 0, disparEnemic.getWidth(), disparEnemic.getHeight()));
							disparEnemicFinal = 0;
							disparAparecerEnemic += 1000;
						}


						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setX(y.getX() + (y.getWidth() / 2));
						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setY(y.getY());

					}
					synchronized (y) {
						y.setX(movimentHoritzontalNaus2);

					}
					for (Sprite disparou: spritestretsPantalla ) {
						float tretX = disparou.getX() + (disparou.getWidth()/2);
						float trety = disparou.getY() + (disparou.getHeight());

						if (trety >= y.getY() && trety <= y.getY() + y.getHeight() && tretX > y.getX() && tretX < y.getX()+y.getWidth()){
							puntuacion++;
						}
					}

					puntosPantalla = "Puntos totales: " + puntuacion;
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					if (movimentHoritzontalNaus2 >= PANT_AMPL - imgnau2.getWidth() - (5)) {
						movimentVerticalNaus2 = movimentVerticalNaus2 - 50;
					}else if(movimentHoritzontalNaus2 >= sprite1.getX() && movimentHoritzontalNaus2
							<= sprite1.getX() + sprite1.getWidth() && movimentVerticalNaus2<=sprite1.getY()+sprite1.getHeight()){
						movimentVerticalNaus2 = - 1000;
						//y.setY(movimentVerticalNaus2);
						*//*vidasJugador -= 0.50;
						points+=50;
						puntosPantalla2 = "Daño recivido: " + (*//**//*int) (3 - *//**//*points);*//*

					}
					synchronized (y) {
						y.setY((movimentVerticalNaus2));
					}

				}
				for (int posi = movimentHoritzontalNaus2; movimentHoritzontalNaus2 >= 0; movimentHoritzontalNaus2 -= velocitat) {
					if (disparEnemicFinal >= disparAparecerEnemic) {
						synchronized (this) {
							spritestretsEnemicsPantalla.add(new Sprite(disparEnemic, 0, 0, disparEnemic.getWidth(), disparEnemic.getHeight()));
							disparEnemicFinal = 0;
							disparAparecerEnemic += 1000;
						}


						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setX(y.getX() + (y.getWidth() / 2));
						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setY(y.getY());

					}
					synchronized (y) {
						y.setX(movimentHoritzontalNaus2);

					}
					for (Sprite disparou: spritestretsPantalla ) {
						float tretX = disparou.getX() + (disparou.getWidth()/2);
						float trety = disparou.getY() + (disparou.getHeight());

						if (trety >= y.getY() && trety <= y.getY() + y.getHeight() && tretX > y.getX() && tretX < y.getX()+y.getWidth()){
							puntuacion++;
						}
					}
					puntosPantalla = "Puntos totales: " + puntuacion;
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}


					if (movimentHoritzontalNaus2 <= 0 + 5) {
						movimentVerticalNaus2 = movimentVerticalNaus2 - 50;
					}else if(movimentHoritzontalNaus2 >= sprite1.getX() && movimentHoritzontalNaus2
							<= sprite1.getX() + sprite1.getWidth() && movimentVerticalNaus2<=sprite1.getY()+sprite1.getHeight()){
						movimentVerticalNaus2 = - 1000;
						//y.setY(movimentVerticalNaus2);
						*//*vidasJugador -= 0.50;
						points+=50;
						puntosPantalla2 = "Daño recivido: " + (*//**//*int) (3 - *//**//*points);*//*
					}
					synchronized (y) {
						y.setY((movimentVerticalNaus2));
					}
				}
			} else if (direccio == 2) {
				for (int posi = movimentHoritzontalNaus2; movimentHoritzontalNaus2 >= 0; movimentHoritzontalNaus2 -= velocitat) {
					if (disparEnemicFinal >= disparAparecerEnemic) {
						synchronized (this) {
							spritestretsEnemicsPantalla.add(new Sprite(disparEnemic, 0, 0, disparEnemic.getWidth(), disparEnemic.getHeight()));
							disparEnemicFinal = 0;
							disparAparecerEnemic += 1000;
						}


						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setX(y.getX() + (y.getWidth() / 2));
						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setY(y.getY());

					}
					synchronized (y) {
						y.setX(movimentHoritzontalNaus2);

					}
					for (Sprite disparou: spritestretsPantalla ) {
						float tretX = disparou.getX() + (disparou.getWidth()/2);
						float trety = disparou.getY() + (disparou.getHeight());

						if (trety >= y.getY() && trety <= y.getY() + y.getHeight() && tretX > y.getX() && tretX < y.getX()+y.getWidth()){
							puntuacion++;
						}
					}
					puntosPantalla = "Puntos totales: " + puntuacion;
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}


					if (movimentHoritzontalNaus2 <= 0 + 5) {
						movimentVerticalNaus2 = movimentVerticalNaus2 - 50;
					}else if(movimentHoritzontalNaus2 >= sprite1.getX() && movimentHoritzontalNaus2
							<= sprite1.getX() + sprite1.getWidth() && movimentVerticalNaus2<=sprite1.getY()+sprite1.getHeight()){
						movimentVerticalNaus2 = - 1000;
						//y.setY(movimentVerticalNaus2);
						*//*vidasJugador -= 0.50;
						points+=50;
						puntosPantalla2 = "Daño recivido: " + (*//**//*int) (3 - *//**//*points);*//*
					}
					synchronized (y) {
						y.setY((movimentVerticalNaus2));
					}
				}
				for (int posi = movimentHoritzontalNaus2; movimentHoritzontalNaus2 <= PANT_AMPL - imgnau2.getWidth(); movimentHoritzontalNaus2 += velocitat) {
					if (disparEnemicFinal >= disparAparecerEnemic) {
						synchronized (this) {
							spritestretsEnemicsPantalla.add(new Sprite(disparEnemic, 0, 0, disparEnemic.getWidth(), disparEnemic.getHeight()));
							disparEnemicFinal = 0;
							disparAparecerEnemic += 1000;
						}


						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setX(y.getX() + (y.getWidth() / 2));
						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setY(y.getY());

					}
					synchronized (y) {
						y.setX(movimentHoritzontalNaus2);

					}
					for (Sprite disparou: spritestretsPantalla ) {
						float tretX = disparou.getX() + (disparou.getWidth()/2);
						float trety = disparou.getY() + (disparou.getHeight());

						if (trety >= y.getY() && trety <= y.getY() + y.getHeight() && tretX > y.getX() && tretX < y.getX()+y.getWidth()){
							puntuacion++;
						}
					}
					puntosPantalla = "Puntos totales: " + puntuacion;
					*//*puntuacion++;
					puntosPantalla = "Puntos totales: " + puntuacion;*//*
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}


					if (movimentHoritzontalNaus2 >= PANT_AMPL - imgnau2.getWidth() - 5) {
						movimentVerticalNaus2 = movimentVerticalNaus2 - 50;

					}else if(movimentHoritzontalNaus2 >= sprite1.getX() && movimentHoritzontalNaus2
							<= sprite1.getX() + sprite1.getWidth() && movimentVerticalNaus2<=sprite1.getY()+sprite1.getHeight()){
						movimentVerticalNaus2 = - 1000;
						//y.setY(movimentVerticalNaus2);
						*//*vidasJugador -= 0.50;
						points+=50;
						puntosPantalla2 = "Daño recivido: " + (*//**//*int) (3 - *//**//*points);*//*
					}
					synchronized (y) {
						y.setY((movimentVerticalNaus2));
					}
				}
			}

		}
		if (y.getY()==-1000){
			sprites.remove(y);
		}else if (y.getY() <= sprite1.getY()){
			*//*y.setX(0 );
			y.setY((0- y.getHeight()));*//*
			sprites.remove(y);
		}*/



		//}
		//}

	}

	@Override
	public void dispose () {
		batch.dispose();
		//botodret.dispose();
		font.dispose();
		font2.dispose();
	}

	@Override
	public void run() {

	//movilizar(sprites.get(naveActual));
		boolean nauMorta = false;
		int vidasenemigas = 3;
		Sprite y = sprites.get(sprites.size()-1);
		int movimentHoritzontalNaus2 = PANT_AMPL / 2 - (imgnau2.getWidth() / 2);
		int movimentVerticalNaus2 = PANT_LLAR - imgnau2.getHeight();
		int movimentVerticalFinal = /*(PANT_LLAR + 300) - (PANT_LLAR)*/(int) (sprite1.getY()/*+sprite1.getHeight()*/);

		int direccio = (int) (1 + (Math.random() * 2));
		int velocitat = (int) (1 + (Math.random() * 4));

		boolean control = false;



		/*movimentHoritzontalNaus2 = PANT_AMPL / 2 - (imgnau2.getWidth() / 2);
		movimentVerticalNaus2 = PANT_LLAR - imgnau2.getHeight();*/
		//for (Sprite y : prueba) {
		synchronized (y) {
			y.setX(PANT_AMPL / 2 - (imgnau2.getWidth() / 2));
			y.setY(PANT_LLAR - imgnau2.getHeight());
		}

		while(movimentVerticalFinal < movimentVerticalNaus2 /*&& vidasJugador > 0*/ && !nauMorta){




			if (direccio == 1) {

				for (int posi = movimentHoritzontalNaus2; movimentHoritzontalNaus2 < PANT_AMPL - imgnau2.getWidth(); movimentHoritzontalNaus2 += velocitat) {
					if (disparEnemicFinal >= disparAparecerEnemic) {
						synchronized (this) {
							spritestretsEnemicsPantalla.add(new Sprite(disparEnemic, 0, 0, disparEnemic.getWidth(), disparEnemic.getHeight()));
							disparEnemicFinal = 0;
							disparAparecerEnemic += 1000;
						}


						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setX(y.getX() + (y.getWidth() / 2));
						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setY(y.getY());

					}
					synchronized (y) {
						if (vidasenemigas>0) {
							y.setX(movimentHoritzontalNaus2);
						}
					}
					for (Sprite disparou: spritestretsPantalla ) {
						float tretX = disparou.getX() + (disparou.getWidth()/2);
						float trety = disparou.getY() + (disparou.getHeight());

						if (trety >= y.getY() && trety <= y.getY() + y.getHeight() && tretX > y.getX() && tretX < y.getX()+y.getWidth()){
							puntuacion+=25;
							disparou.setY(-100);
							disparou.setX(-100);
							vidasenemigas--;
							if (vidasenemigas <= 0){
								y.setY(-1000);
								y.setX(-1000);
								sprites.remove(y);
							}
						}
					}

					puntosPantalla = "Puntos totales: " + puntuacion;
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					if (movimentHoritzontalNaus2 >= PANT_AMPL - imgnau2.getWidth() - (5)) {
						movimentVerticalNaus2 = movimentVerticalNaus2 - 50;
					}else if(movimentHoritzontalNaus2 >= sprite1.getX() && movimentHoritzontalNaus2
							<= sprite1.getX() + sprite1.getWidth() && movimentVerticalNaus2<=sprite1.getY()+sprite1.getHeight()){
						movimentVerticalNaus2 = - 1000;
						//y.setY(movimentVerticalNaus2);
						/*vidasJugador -= 0.50;
						points+=50;
						puntosPantalla2 = "Daño recivido: " + (*//*int) (3 - *//*points);*/
					}
					synchronized (y) {
						if (vidasenemigas>0) {
							y.setY((movimentVerticalNaus2));
						}
					}

				}
				for (int posi = movimentHoritzontalNaus2; movimentHoritzontalNaus2 >= 0; movimentHoritzontalNaus2 -= velocitat) {
					if (disparEnemicFinal >= disparAparecerEnemic) {
						synchronized (this) {
							spritestretsEnemicsPantalla.add(new Sprite(disparEnemic, 0, 0, disparEnemic.getWidth(), disparEnemic.getHeight()));
							disparEnemicFinal = 0;
							disparAparecerEnemic += 1000;
						}


						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setX(y.getX() + (y.getWidth() / 2));
						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setY(y.getY());

					}
					synchronized (y) {
						if (vidasenemigas>0) {
							y.setX(movimentHoritzontalNaus2);
						}

					}
					for (Sprite disparou: spritestretsPantalla ) {
						float tretX = disparou.getX() + (disparou.getWidth()/2);
						float trety = disparou.getY() + (disparou.getHeight());

						if (trety >= y.getY() && trety <= y.getY() + y.getHeight() && tretX > y.getX() && tretX < y.getX()+y.getWidth()){
							puntuacion+=25;
							disparou.setY(-100);
							disparou.setX(-100);
							vidasenemigas--;
							if (vidasenemigas <= 0){
								y.setY(-1000);
								y.setX(-1000);
								sprites.remove(y);
							}
						}
					}
					puntosPantalla = "Puntos totales: " + puntuacion;
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}


					if (movimentHoritzontalNaus2 <= 0 + 5) {
						movimentVerticalNaus2 = movimentVerticalNaus2 - 50;
					}else if(movimentHoritzontalNaus2 >= sprite1.getX() && movimentHoritzontalNaus2
							<= sprite1.getX() + sprite1.getWidth() && movimentVerticalNaus2<=sprite1.getY()+sprite1.getHeight()){
						movimentVerticalNaus2 = - 1000;
						//y.setY(movimentVerticalNaus2);
						/*vidasJugador -= 0.50;
						points+=50;
						puntosPantalla2 = "Daño recivido: " + (*//*int) (3 - *//*points);*/
					}
					synchronized (y) {
						if (vidasenemigas>0) {
							y.setY((movimentVerticalNaus2));
						}
					}
				}
			} else if (direccio == 2) {
				for (int posi = movimentHoritzontalNaus2; movimentHoritzontalNaus2 >= 0; movimentHoritzontalNaus2 -= velocitat) {
					if (disparEnemicFinal >= disparAparecerEnemic) {
						synchronized (this) {
							spritestretsEnemicsPantalla.add(new Sprite(disparEnemic, 0, 0, disparEnemic.getWidth(), disparEnemic.getHeight()));
							disparEnemicFinal = 0;
							disparAparecerEnemic += 1000;
						}


						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setX(y.getX() + (y.getWidth() / 2));
						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setY(y.getY());

					}
					synchronized (y) {
						if (vidasenemigas>0) {
							y.setX(movimentHoritzontalNaus2);
						}

					}
					for (Sprite disparou: spritestretsPantalla ) {
						float tretX = disparou.getX() + (disparou.getWidth()/2);
						float trety = disparou.getY() + (disparou.getHeight());

						if (trety >= y.getY() && trety <= y.getY() + y.getHeight() && tretX > y.getX() && tretX < y.getX()+y.getWidth()){
							puntuacion+=25;
							disparou.setY(-100);
							disparou.setX(-100);
							vidasenemigas--;
							if (vidasenemigas <= 0){
								y.setY(-1000);
								y.setX(-1000);
								sprites.remove(y);
							}
						}
					}
					puntosPantalla = "Puntos totales: " + puntuacion;
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}


					if (movimentHoritzontalNaus2 <= 0 + 5) {
						movimentVerticalNaus2 = movimentVerticalNaus2 - 50;
					}else if(movimentHoritzontalNaus2 >= sprite1.getX() && movimentHoritzontalNaus2
							<= sprite1.getX() + sprite1.getWidth() && movimentVerticalNaus2<=sprite1.getY()+sprite1.getHeight()){
						movimentVerticalNaus2 = - 1000;
						//y.setY(movimentVerticalNaus2);
						/*vidasJugador -= 0.50;
						points+=50;
						puntosPantalla2 = "Daño recivido: " + (*//*int) (3 - *//*points);*/
					}
					synchronized (y) {
						if (vidasenemigas>0) {
							y.setY((movimentVerticalNaus2));
						}
					}
				}
				for (int posi = movimentHoritzontalNaus2; movimentHoritzontalNaus2 <= PANT_AMPL - imgnau2.getWidth(); movimentHoritzontalNaus2 += velocitat) {
					if (disparEnemicFinal >= disparAparecerEnemic) {
						synchronized (this) {
							spritestretsEnemicsPantalla.add(new Sprite(disparEnemic, 0, 0, disparEnemic.getWidth(), disparEnemic.getHeight()));
							disparEnemicFinal = 0;
							disparAparecerEnemic += 1000;
						}


						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setX(y.getX() + (y.getWidth() / 2));
						spritestretsEnemicsPantalla.get(spritestretsEnemicsPantalla.size() - 1).setY(y.getY());

					}
					synchronized (y) {
						if (vidasenemigas>0) {
							y.setX(movimentHoritzontalNaus2);
						}

					}
					for (Sprite disparou: spritestretsPantalla ) {
						float tretX = disparou.getX() + (disparou.getWidth()/2);
						float trety = disparou.getY() + (disparou.getHeight());

						if (trety >= y.getY() && trety <= y.getY() + y.getHeight() && tretX > y.getX() && tretX < y.getX()+y.getWidth()){
							puntuacion+=25;
							disparou.setY(-100);
							disparou.setX(-100);
							vidasenemigas--;
							if (vidasenemigas <= 0){
								y.setY(-1000);
								y.setX(-1000);
								sprites.remove(y);
							}
						}
					}
					puntosPantalla = "Puntos totales: " + puntuacion;
					/*puntuacion++;
					puntosPantalla = "Puntos totales: " + puntuacion;*/
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}


					if (movimentHoritzontalNaus2 >= PANT_AMPL - imgnau2.getWidth() - 5) {
						movimentVerticalNaus2 = movimentVerticalNaus2 - 50;

					}else if(movimentHoritzontalNaus2 >= sprite1.getX() && movimentHoritzontalNaus2
							<= sprite1.getX() + sprite1.getWidth() && movimentVerticalNaus2<=sprite1.getY()+sprite1.getHeight()){
						movimentVerticalNaus2 = - 1000;
						//y.setY(movimentVerticalNaus2);
						/*vidasJugador -= 0.50;
						points+=50;
						puntosPantalla2 = "Daño recivido: " + (*//*int) (3 - *//*points);*/
					}
					synchronized (y) {
						if (vidasenemigas>0) {
							y.setY((movimentVerticalNaus2));
						}
					}
				}
			}

		}
		if (y.getY()==-1000){
			sprites.remove(y);

		}else if (y.getY() <= sprite1.getY()){
			y.setX(0 );
			y.setY((0- y.getHeight()));
			sprites.remove(y);
		}
		for (Sprite disparou: spritestretsPantalla ) {
			if (disparou.getY() == -1000 && disparou.getX() == -1000){
				aRemover.add(disparou);
			}
		}
		/*if (vidasJugador<=0){

		}*/
	}


	@Override
	public boolean keyDown(int keycode) {
		float novaPos;
		switch (keycode){
			case Input.Keys.DPAD_LEFT:
				novaPos = sprite1.getX()-15;
				if (novaPos>=0) {
					sprite1.setX(novaPos);
				}
				break;
			case Input.Keys.DPAD_RIGHT:
				novaPos = sprite1.getX()+15;
				if (novaPos<=PANT_AMPL - sprite1.getWidth()) {
					sprite1.setX(novaPos);
				}
				break;
			case Input.Keys.DPAD_UP:
				if (spritestrets.size() == 2){

					//spritestrets.get(1).setX(screenX + (sprite1.getWidth() /2) - (sprite1.getWidth() /2) );
					spritestrets.get(1).setX(sprite1.getX() + (sprite1.getWidth()/2));
					spritestrets.get(1).setY(200 + (imgnau1.getHeight()) + (spritestrets.get(1).getHeight()));
					//spritestrets.remove(spritestrets.get(1));
					control = true;
					spritestretsPantalla.add(spritestrets.get(1));
					spritestrets.remove(spritestrets.get(1));
				}else if (spritestrets.size() == 1){

					//spritestrets.get(0).setX(screenX + (sprite1.getWidth() /2) - (sprite1.getWidth() /2) );
					spritestrets.get(0).setX(sprite1.getX() + (sprite1.getWidth()/2));
					spritestrets.get(0).setY(200 + (imgnau1.getHeight()) + (spritestrets.get(0).getHeight()));
					//spritestrets.remove(spritestrets.get(0));
					control = true;
					spritestretsPantalla.add(spritestrets.get(0));
					spritestrets.remove(spritestrets.get(0));
				}
				break;
		}
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {

		//screenY = (int) (screenY - (tret1.getHeight() /2));





		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {


		screenX = (int) (screenX - (dispar.getWidth() /2));
		if (spritestrets.size() == 2){

			//spritestrets.get(1).setX(screenX + (sprite1.getWidth() /2) - (sprite1.getWidth() /2) );
			spritestrets.get(1).setX(sprite1.getX() + (sprite1.getWidth()/2));
			spritestrets.get(1).setY(200 + (imgnau1.getHeight()) + (spritestrets.get(1).getHeight()));
				//spritestrets.remove(spritestrets.get(1));
			control = true;
			spritestretsPantalla.add(spritestrets.get(1));
			spritestrets.remove(spritestrets.get(1));
		}else if (spritestrets.size() == 1){

			//spritestrets.get(0).setX(screenX + (sprite1.getWidth() /2) - (sprite1.getWidth() /2) );
			spritestrets.get(0).setX(sprite1.getX() + (sprite1.getWidth()/2));
			spritestrets.get(0).setY(200 + (imgnau1.getHeight()) + (spritestrets.get(0).getHeight()));
			//spritestrets.remove(spritestrets.get(0));
			control = true;
			spritestretsPantalla.add(spritestrets.get(0));
			spritestrets.remove(spritestrets.get(0));
		}

		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		screenX = (int) (screenX - (sprite1.getWidth() /2));
		/*sprite1.setX(screenX);
		sprite1.setY(150 + (imgnau1.getHeight()/2F));*/

		if (screenX>sprite1.getX()){
			//if (screenX<PANT_AMPL-(sprite1.getWidth())){
				sprite1.setX(sprite1.getX()+20);
				sprite1.setY(150 + (imgnau1.getHeight()/2F));
			//}

		}
		if (screenX<sprite1.getX()){
			//if (screenX>=0) {
				sprite1.setX(sprite1.getX() - 20);
				sprite1.setY(150 + (imgnau1.getHeight() / 2F));
			//}
		}



		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}

	@Override
	public boolean scrolled(float amountX, float amountY) {
		return false;
	}
}
